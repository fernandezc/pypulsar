# -*- encoding: iso-8859-1 -*-
# above encoding b/c there's a non-ASCII character in the sample output
# of intele
# http://developer.intel.com/software/products/compilers/flin/

from numpy.distutils.cpuinfo import cpu
from numpy.distutils.ccompiler import simple_version_match
from numpy.distutils.fcompiler import FCompiler, dummy_fortran_file

compilers = ['IntelFCompiler', 'IntelVisualFCompiler',
             'IntelItaniumFCompiler', 'IntelItaniumVisualFCompiler',
             'IntelEM64TFCompiler']

def intel_version_match(type):
    # Match against the important stuff in the version string
#    return simple_version_match(start=r'Intel.*?Fortran.*?(?:%s).*?Version' % (type,))
    return simple_version_match(start=r'Intel\(R\).*?Fortran.*?(?:%s).*Version(?P<version>.*)Build' % (type,))

class BaseIntelFCompiler(FCompiler):
    def update_executables(self):
        f = dummy_fortran_file()
#        self.executables['version_cmd'] = ['<F77>', '-FI', '-V', '-c',
#                                          f + '.f', '-o', f + '.o']
        self.executables['version_cmd'] = ["<F90>", "/help"]

class IntelFCompiler(BaseIntelFCompiler):

    compiler_type = 'intel'
    compiler_aliases = ('ifort',)
    description = 'Intel Fortran Compiler for 32-bit apps'
    version_match = intel_version_match('IA-32')

    possible_executables = ['ifort']

    executables = {
        'version_cmd'  : None,          # set by update_executables
        'compiler_f77' : ["ifort", "-72", "-w90", "-w95"],
        'compiler_f90' : ["ifort"],
        'compiler_fix' : ["ifort", "-FI"],
        'linker_so'    : ["<F90>", "-shared"],
        'archiver'     : ["ar", "-cr"],
        'ranlib'       : ["ranlib"]
        }

    pic_flags = ['-KPIC']
    module_dir_switch = '-module ' # Don't remove ending space!
    module_include_switch = '-I'

    def get_flags(self):
        opt = self.pic_flags + ["-cm"]
        return opt

    def get_flags_free(self):
        return ["-FR"]

    def get_flags_opt(self):
        return ['-O3','-unroll']

    def get_flags_arch(self):
        v = self.get_version()
        opt = []
        if cpu.has_fdiv_bug():
            opt.append('-fdiv_check')
        if cpu.has_f00f_bug():
            opt.append('-0f_check')
        if cpu.is_PentiumPro() or cpu.is_PentiumII() or cpu.is_PentiumIII():
            opt.extend(['-tpp6'])
        elif cpu.is_PentiumM():
            opt.extend(['-tpp7','-xB'])
        elif cpu.is_Pentium():
            opt.append('-tpp5')
        elif cpu.is_PentiumIV() or cpu.is_Xeon():
            opt.extend(['-tpp7','-xW'])
        if v and v <= '7.1':
            if cpu.has_mmx() and (cpu.is_PentiumII() or cpu.is_PentiumIII()):
                opt.append('-xM')
        elif v and v >= '8.0':
            if cpu.is_PentiumIII():
                opt.append('-xK')
                if cpu.has_sse3():
                    opt.extend(['-xP'])
            elif cpu.is_PentiumIV():
                opt.append('-xW')
                if cpu.has_sse2():
                    opt.append('-xN')
            elif cpu.is_PentiumM():
                opt.extend(['-xB'])
            if (cpu.is_Xeon() or cpu.is_Core2() or cpu.is_Core2Extreme()) and cpu.getNCPUs()==2:
                opt.extend(['-xT'])
            if cpu.has_sse3() and (cpu.is_PentiumIV() or cpu.is_CoreDuo() or cpu.is_CoreSolo()):
                opt.extend(['-xP'])

        if cpu.has_sse2():
            opt.append('-arch SSE2')
        elif cpu.has_sse():
            opt.append('-arch SSE')
        return opt

    def get_flags_linker_so(self):
        opt = FCompiler.get_flags_linker_so(self)
        v = self.get_version()
        if v and v >= '8.0':
            opt.append('-nofor_main')
        return opt

class IntelItaniumFCompiler(IntelFCompiler):
    compiler_type = 'intele'
    compiler_aliases = ()
    description = 'Intel Fortran Compiler for Itanium apps'

    version_match = intel_version_match('Itanium')

#Intel(R) Fortran Itanium(R) Compiler for Itanium(R)-based applications
#Version 9.1� � Build 20060928 Package ID: l_fc_c_9.1.039
#Copyright (C) 1985-2006 Intel Corporation.� All rights reserved.
#30 DAY EVALUATION LICENSE

    possible_executables = ['ifort', 'efort', 'efc']

    executables = {
        'version_cmd'  : None,
        'compiler_f77' : [None, "-FI", "-w90", "-w95"],
        'compiler_fix' : [None, "-FI"],
        'compiler_f90' : [None],
        'linker_so'    : ['<F90>', "-shared"],
        'archiver'     : ["ar", "-cr"],
        'ranlib'       : ["ranlib"]
        }

class IntelEM64TFCompiler(IntelFCompiler):
    compiler_type = 'intelem'
    compiler_aliases = ()
    description = 'Intel Fortran Compiler for EM64T-based apps'

    version_match = intel_version_match('EM64T-based|Intel\\(R\\) 64')

    possible_executables = ['ifort', 'efort', 'efc']

    executables = {
        'version_cmd'  : None,
        'compiler_f77' : ["ifort", "-FI", "-w90", "-w95"],
        'compiler_fix' : ["ifort", "-FI"],
        'compiler_f90' : ["ifort"],
        'linker_so'    : ['<F90>', "-shared"],
        'archiver'     : ["ar", "-cr"],
        'ranlib'       : ["ranlib"]
        }

    def get_flags(self):
        v = self.get_version()
        if v >= '10.0':
            # Use -fPIC instead of -KPIC.
            return ['-fPIC', '-cm']
        else:
            return IntelFCompiler.get_flags(self)

    def get_flags_arch(self):
        opt = []
        if cpu.is_PentiumIV() or cpu.is_Xeon():
            opt.extend(['-tpp7', '-xW'])
        return opt

# Is there no difference in the version string between the above compilers
# and the Visual compilers?

class IntelVisualFCompiler(BaseIntelFCompiler):
    compiler_type = 'intelv'
    description = 'Intel Visual Fortran Compiler for 32-bit apps'
#    version_match = intel_version_match('IA-32')
    version_pattern = r'Intel.*?Fortran.*?IA-32.*?Version(?P<version>.*)Build' 

    ar_exe = 'lib.exe'
    possible_executables = ['ifort',]

    executables = {
        'version_cmd'  : ["<F90>", "/help"],
        'compiler_f77' : ["ifort","/FI"],
        'compiler_fix' : ["ifort","/FI","/4L72"],
        'compiler_f90' : ["ifort"],
        'linker_so'    : ['<F90>'],
        'archiver'     : [ar_exe, "/verbose", "/OUT:"],
        'ranlib'       : None
        }

    compile_switch = '/c '
    object_switch = '/Fo'     #No space after /Fo!
    library_switch = '/OUT:'  #No space after /OUT:!
    module_dir_switch = '/module:' #No space after /module:
    module_include_switch = '/I'
    obj_extension = ".obj"
    
    def get_flags(self):
        opt = ['/nologo','/MD','/nbs','/Qlowercase','/us','/w','/QaxPT' ]
        return opt

    def get_flags_free(self):
        return ["/FR"]

    def get_flags_debug(self):
        return ['/Zi']

    def get_flags_opt(self):
        return ['/O3']

    #def get_flags_arch(self):
        #opt = []
        # if cpu.is_PentiumPro() or cpu.is_PentiumII():
            # opt.extend(['/G6','/Qaxi'])
        # elif cpu.is_PentiumIII():
            # opt.extend(['/G6','/QaxK'])
        # elif cpu.is_Pentium():
            # opt.append('/G5')
        # elif cpu.is_PentiumIV():
            # opt.extend(['/G7','/QaxW'])
        # # if cpu.has_mmx():
            # #opt.append('/QaxM')
        # return opt

class IntelItaniumVisualFCompiler(IntelVisualFCompiler):
    compiler_type = 'intelev'
    description = 'Intel Visual Fortran Compiler for Itanium apps'

    version_match = intel_version_match('Itanium')

    possible_executables = ['efl'] # XXX this is a wild guess
    ar_exe = IntelVisualFCompiler.ar_exe

    executables = {
        'version_cmd'  : None,
        'compiler_f77' : [None,"-FI","-w90","-w95"],
        'compiler_fix' : [None,"-FI","-4L72","-w"],
        'compiler_f90' : [None],
        'linker_so'    : ['<F90>',"-shared"],
        'archiver'     : [ar_exe, "/verbose", "/OUT:"],
        'ranlib'       : None
        }

if __name__ == '__main__':
    from distutils import log
    log.set_verbosity(2)
    from numpy.distutils.fcompiler import new_fcompiler
    compiler = new_fcompiler(compiler='intel')
    compiler.customize()
    print compiler.get_version()
